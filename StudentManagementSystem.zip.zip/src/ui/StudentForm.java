package ui;

import javax.swing.*;
import java.awt.*;
import dao.StudentDAO;
import model.Student;

public class StudentForm extends JFrame {

    private JTextField txtId, txtName, txtEmail;
    private JComboBox<String> cmbCourse;
    private StudentDAO dao = new StudentDAO();

    public StudentForm() {
        setTitle("Student Management System - Form");
        setSize(450, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("ID (Update/Delete):"), gbc);

        gbc.gridx = 1;
        txtId = new JTextField(15);
        panel.add(txtId, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Name:"), gbc);

        gbc.gridx = 1;
        txtName = new JTextField(15);
        panel.add(txtName, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Email:"), gbc);

        gbc.gridx = 1;
        txtEmail = new JTextField(15);
        panel.add(txtEmail, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Course:"), gbc);

        gbc.gridx = 1;
        String[] courses = {"B.Tech","BCA","MCA","BBA","MBA","Diploma"};
        cmbCourse = new JComboBox<>(courses);
        panel.add(cmbCourse, gbc);

        // Buttons Row
        JPanel btnPanel = new JPanel(new FlowLayout());
        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnTable = new JButton("Show Table");

        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnTable);

        gbc.gridwidth = 2;
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(btnPanel, gbc);

        add(panel);

        // Actions
        btnAdd.addActionListener(e -> addStudent());
        btnUpdate.addActionListener(e -> updateStudent());
        btnDelete.addActionListener(e -> deleteStudent());
        btnTable.addActionListener(e -> {
            new StudentTable().setVisible(true);
            this.dispose();
        });
    }
        private void addStudent() {
            String name = txtName.getText();
            String email = txtEmail.getText();
            String course = (String)cmbCourse.getSelectedItem();

            if(name.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty!");
                return;
            }

            if(!email.contains("@") || !email.contains(".")) {
                JOptionPane.showMessageDialog(this, "Invalid Email Format!");
                return;
            }

            boolean status = dao.addStudent(new Student(name, email, course));
            JOptionPane.showMessageDialog(this, status ? "Student Added!" : "Error Adding Student!");
        }
        
        private void updateStudent() {
            if(txtId.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter ID for update!");
                return;
            }

            int id = Integer.parseInt(txtId.getText());
            String name = txtName.getText();
            String email = txtEmail.getText();
            String course = (String)cmbCourse.getSelectedItem();

            boolean status = dao.updateStudent(new Student(id, name, email, course));
            JOptionPane.showMessageDialog(this, status ? "Updated!" : "Update Failed!");
        }
        
        private void deleteStudent() {
            if(txtId.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter ID to delete!");
                return;
            }

            int id = Integer.parseInt(txtId.getText());
            boolean status = dao.deleteStudent(id);
            JOptionPane.showMessageDialog(this, status ? "Deleted!" : "Delete Failed!");
        }
}
