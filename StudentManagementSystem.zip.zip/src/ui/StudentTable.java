package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import dao.StudentDAO;
import model.Student;

public class StudentTable extends JFrame {

    private JTable table;
    private JTextField txtSearch;
    private StudentDAO dao = new StudentDAO();

    public StudentTable() {
        setTitle("Student Records");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel topPanel = new JPanel();
        txtSearch = new JTextField(15);
        JButton btnSearch = new JButton("Search");
        JButton btnRefresh = new JButton("Refresh");
        JButton btnBack = new JButton("Back");

        topPanel.add(new JLabel("Search: "));
        topPanel.add(txtSearch);
        topPanel.add(btnSearch);
        topPanel.add(btnRefresh);
        topPanel.add(btnBack);

        add(topPanel, BorderLayout.NORTH);

        table = new JTable();
        loadTableData();
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnSearch.addActionListener(e -> searchData());
        btnRefresh.addActionListener(e -> loadTableData());
        btnBack.addActionListener(e -> {
            new StudentForm().setVisible(true);
            this.dispose();
        });
    }

    private void loadTableData() {
        List<Student> list = dao.getAllStudents();
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID","Name","Email","Course"}, 0);

        for (Student s : list) {
            model.addRow(new Object[]{s.getId(), s.getName(), s.getEmail(), s.getCourse()});
        }

        table.setModel(model);
    }

    private void searchData() {
        String keyword = txtSearch.getText();
        List<Student> list = dao.searchStudents(keyword);
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID","Name","Email","Course"}, 0);

        for (Student s : list) {
            model.addRow(new Object[]{s.getId(), s.getName(), s.getEmail(), s.getCourse()});
        }

        table.setModel(model);
    }
}
